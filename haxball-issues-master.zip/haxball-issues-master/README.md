# HaxBall Issues

Before reporting an issue try searching for open issues, avoid creating duplicates.

If you have connection issues read this: https://github.com/haxball/haxball-issues/wiki/Connection-Issues
